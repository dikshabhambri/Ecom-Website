# E-Commerce-Store[DEMO](https://vinita2000.github.io/E-Commerce-Website/)
Mimicking an e commerce store using HTML, CSS , Javascript and JQuery
![products-image](images/products.png)
![cart-image](images/cart.png)
